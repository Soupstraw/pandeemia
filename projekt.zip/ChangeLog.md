# Changelog for balti-pandeemia

## Unreleased changes
